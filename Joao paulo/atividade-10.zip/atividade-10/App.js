import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [idades, setIdade] = useState('');
  const [categoria, setCategoria] = useState('');

  const classificarIdade = () => {
    const idade = parseFloat(idades);

    if (isNaN(idade)) {
      Alert.alert('Erro', 'Por favor, insira uma idade valida.');
      return;
    }

    switch (true){
      case (idade >= 5 && idade < 7):
        setCategoria("Infantil A");
        break;
        case (idade >= 8 && idade < 10):
        setCategoria("Infantil B");
        break;
        case (idade >= 11 && idade < 13):
        setCategoria("Juvenil A");
        break;
        case (idade >= 14 && idade < 18):
        setCategoria("Juvenil B");
        break;
        case (idade >= 18):
        setCategoria("Adulto");
        break;
        default: setCategoria('Fora das faixas etárias definidas');

    }
       
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Soma</Text>
      <TextInput
        style={styles.input}
        placeholder="Coloque a sua idade"
        keyboardType="numeric"
        value={idades}
        onChangeText={setIdade}
      />
     
      <Button title="Classificação por idade" onPress={classificarIdade} />
      {categoria !== '' && (
        <Text style={styles.result}>=Classificação: {categoria}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  result: {
    marginTop: 16,
    fontSize: 20,
    color: '#333',
  },
});