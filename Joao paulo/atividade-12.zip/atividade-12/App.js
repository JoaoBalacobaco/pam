import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [sideA, setSideA] = useState('');
  const [sideB, setSideB] = useState('');
  const [sideC, setSideC] = useState('');
  const [result, setResult] = useState('');

  const checkTriangle = () => {
    const a = parseFloat(sideA);
    const b = parseFloat(sideB);
    const c = parseFloat(sideC);

    if (isNaN(a) || isNaN(b) || isNaN(c)) {
      Alert.alert('Erro', 'Por favor, insira valores válidos.');
      return;
    }

    // Verificar se os valores formam um triângulo
    if (a + b > c && a + c > b && b + c > a) {
      // Determinar o tipo de triângulo
      if (a === b && b === c) {
        setResult('Os lados formam um triângulo equilátero.');
      } else if (a === b || a === c || b === c) {
        setResult('Os lados formam um triângulo isósceles.');
      } else {
        setResult('Os lados formam um triângulo escaleno.');
      }
    } else {
      setResult('Os valores não formam um triângulo.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Verificador de Triângulos</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o lado A"
        keyboardType="numeric"
        value={sideA}
        onChangeText={setSideA}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite o lado B"
        keyboardType="numeric"
        value={sideB}
        onChangeText={setSideB}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite o lado C"
        keyboardType="numeric"
        value={sideC}
        onChangeText={setSideC}
      />
      <Button title="Verificar" onPress={checkTriangle} />
      {result !== '' && <Text style={styles.result}>{result}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    fontSize: 18,
    marginBottom: 15,
  },
  result: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
