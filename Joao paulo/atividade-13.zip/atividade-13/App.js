import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [age, setAge] = useState('');
  const [height, setHeight] = useState('');
  const [gender, setGender] = useState('');
  const [idealWeight, setIdealWeight] = useState('');

  const calculateIdealWeight = () => {
    const parsedAge = parseInt(age);
    const parsedHeight = parseFloat(height);
    const parsedGender = gender.toUpperCase();

    if (isNaN(parsedAge) || isNaN(parsedHeight) || (parsedGender !== 'M' && parsedGender !== 'F')) {
      Alert.alert('Erro', 'Por favor, insira valores válidos.');
      return;
    }

    let weight = 0;

    if (parsedGender === 'M') {
      if (parsedHeight > 1.70) {
        if (parsedAge <= 20) {
          weight = (72.7 * parsedHeight) - 58;
        } else if (parsedAge <= 39) {
          weight = (72.7 * parsedHeight) - 53;
        } else {
          weight = (72.7 * parsedHeight) - 45;
        }
      } else {
        if (parsedAge <= 40) {
          weight = (72.7 * parsedHeight) - 50;
        } else {
          weight = (72.7 * parsedHeight) - 58;
        }
      }
    } else if (parsedGender === 'F') {
      if (parsedHeight > 1.50) {
        weight = (62.1 * parsedHeight) - 44.7;
      } else {
        if (parsedAge >= 35) {
          weight = (62.1 * parsedHeight) - 45;
        } else {
          weight = (62.1 * parsedHeight) - 49;
        }
      }
    }

    setIdealWeight(`Peso ideal: ${weight.toFixed(2)} kg`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Peso Ideal</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite sua idade"
        keyboardType="numeric"
        value={age}
        onChangeText={setAge}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite sua altura (em metros)"
        keyboardType="numeric"
        value={height}
        onChangeText={setHeight}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite seu sexo (M ou F)"
        value={gender}
        onChangeText={setGender}
      />
      <Button title="Calcular" onPress={calculateIdealWeight} />
      {idealWeight !== '' && <Text style={styles.result}>{idealWeight}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    fontSize: 18,
    marginBottom: 15,
  },
  result: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
