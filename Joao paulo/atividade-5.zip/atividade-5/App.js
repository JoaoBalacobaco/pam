import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  const calculateSum = () => {
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);

    if(number1>number2){
      setResult("o valor " + number1 + " é maior que "+ number2)}
     else if (number2>number1)
      {
      setResult("o valor " + number2 + " é maior que "+ number1)
    }
    else {setResult("os valores são iguais")}

  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Soma</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o primeiro número"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite o segundo número"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />
      <Button title="O maior numero é..." onPress={calculateSum} />
      {result !== null && (
        <Text style={styles.result}>Resultado: {result}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  result: {
    marginTop: 16,
    fontSize: 20,
    color: '#333',
  },
});