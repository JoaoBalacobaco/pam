import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [num3, setNum3] = useState('');
  const [result, setResult] = useState(null);

  const calculateSum = () => {
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);
    const number3 = parseFloat(num3);

    if (isNaN(number1) || isNaN(number2) || isNaN(number3)) {
      Alert.alert('Erro', 'Por favor, insira números válidos.');
      return;
    }


    setResult((number1*4+number2*3+number3*3)/(4+3+3));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Soma</Text>
      <TextInput
        style={styles.input}
        placeholder="Coloque o resultado da 1° Prova"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
        style={styles.input}
        placeholder="Coloque o resultado da 2° Prova"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />
      <TextInput
        style={styles.input}
        placeholder="Coloque o resultado da 3° Prova"
        keyboardType="numeric"
        value={num3}
        onChangeText={setNum3}
      />
      <Button title="Resultado da nota" onPress={calculateSum} />
      {result !== null && (
        <div>
        <p style={styles.result}>Resultado: {result}</p>
          {result <= 5 && <p style={styles.recovery}>Reprovado</p>}
          {result >= 7 && <p style={styles.recovery}>Aprovado</p>}
          {result < 7 && result > 5 && <p style={styles.recovery}>Recuperação</p>}
        </div>
        
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  result: {
    marginTop: 16,
    fontSize: 20,
    color: '#333',
  },
});