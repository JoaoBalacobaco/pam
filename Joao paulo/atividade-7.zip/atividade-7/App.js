import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [result, setResult] = useState(null);

  const calculateSum = () => {
    const number1 = parseFloat(num1);

    if (isNaN(number1)) {
      Alert.alert('Erro', 'Por favor, insira números válidos.');
      return;
    }

     if (number1 % 2 === 1){
     setResult ("o numero é impar");
    } else if(number1 % 2 === 0){
     setResult ("o numero é par");
    }
    

    
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Soma</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o primeiro número"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
     
      <Button title="Calcular" onPress={calculateSum} />
      {result !== null && (
        <Text style={styles.result}>Resultado: {result}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  result: {
    marginTop: 16,
    fontSize: 20,
    color: '#333',
  },
});