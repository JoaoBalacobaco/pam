import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [result, setResult] = useState(null);

  const calculateSum = () => {
    const number1 = parseFloat(num1);

    if (isNaN(number1)) {
      Alert.alert('Erro', 'Por favor, insira números válidos.');
      return;
    }

    if (number1 <= 200) {
      setResult("Nenhum crédito adicionado");
    } else if (number1 >= 201 && number1 <= 400) {
      setResult("Adicionado 20% do valor do saldo médio: "+ (number1 + number1 * 0.20));
      }else if(number1 >= 401 && number1 <=600){
         setResult("Adicionado 30% do valor do saldo médio: "+ (number1 + number1 * 0.30));
         }else if(number1 >= 601){
         setResult("Adicionado 40% do valor do saldo médio: "+ (number1 + number1 * 0.40));
       }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Soma</Text>
      <TextInput
        style={styles.input}
        placeholder="Coloque o seu saldo"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
     
      <Button title="Calcular" onPress={calculateSum} />
      {result !== null && (
        <Text style={styles.result}>Resultado: {result}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  result: {
    marginTop: 16,
    fontSize: 20,
    color: '#333',
  },
});