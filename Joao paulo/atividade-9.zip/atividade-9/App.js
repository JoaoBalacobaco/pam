import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [c, setC] = useState('');
  const [delta, setDelta] = useState(null);
  const [result1, setResult1] = useState(null);
  const [result2, setResult2] = useState(null);

  const calculateSum = () => {
    const numa = parseFloat(a);
    const numb = parseFloat(b);
    const numc = parseFloat(c);
    
   const calcDelta= (numb * numb) - (4*numa*numc);
 setDelta(calcDelta);

 if (calcDelta < 0 ) {
   Alert.alert('Erro', 'O valor de delta é negativo.');
   setResult1(null)
   setResult2(null)
      return;
 }
 const x1 = (-(numb)+(Math.sqrt(calcDelta)))/(2*numa);
 const x2 = (-(numb)-(Math.sqrt(calcDelta)))/(2*numa);

 setResult1(x1)
 setResult2(x2)
  };



  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Soma</Text>
      <TextInput
        style={styles.input}
        placeholder="Coloque o valor de A"
        keyboardType="numeric"
        value={a}
        onChangeText={setA}
      />
      <TextInput
        style={styles.input}
        placeholder="Coloque o valor de B"
        keyboardType="numeric"
        value={b}
        onChangeText={setB}
      />
      <TextInput
        style={styles.input}
        placeholder="Coloque o valor de C"
        keyboardType="numeric"
        value={c}
        onChangeText={setC}
      />
      <Button title="Resultado " onPress={calculateSum} />
      {delta !== null && delta < 0 && (
        <Text style={styles.result}>Delta é negativo: {delta} impossivel continuar</Text>
      )}
      
      {result1 !== null && (
        <Text style={styles.result}>Resultado de x1: {result1}</Text>
      )}
      
      {result2 !== null && (
        <Text style={styles.result}>Resultado de x2: {result2}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  result: {
    marginTop: 16,
    fontSize: 20,
    color: '#333',
  },
});